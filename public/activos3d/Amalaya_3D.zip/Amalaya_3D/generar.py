from pathlib import Path
import numpy as np, json, struct, math, zipfile
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.collections import PolyCollection
P=Path(__file__).parent
models=[]
colors={'pink':'#b78089','orange':'#eca65a','yellow':'#dfc568','gray':'#92989b','blue':'#6e9aaa','dark':'#455565','glass':'#699399','panel':'#5c799e'}
def model(id,name,note):
 m={'id':id,'name':name,'note':note,'parts':[]};models.append(m);return m
def box(m,name,x,y,z,w,d,h,col):
 v=[[x,y,z],[x+w,y,z],[x+w,y+d,z],[x,y+d,z],[x,y,z+h],[x+w,y,z+h],[x+w,y+d,z+h],[x,y+d,z+h]]
 f=[[0,3,2,1],[0,1,5,4],[1,2,6,5],[2,3,7,6],[3,0,4,7],[4,5,6,7]]
 m['parts'].append({'name':name,'v':v,'f':f,'c':colors.get(col,col)})
def block(m,n,x,y,w,d,h,c):
 box(m,n,x,y,0,w,d,h,c)
 box(m,n+'_cornisa',x-.15,y-.15,h,w+.3,d+.3,.25,c)
def windows(m,x,y,w,h):
 for i in np.arange(x+1,x+w-1,2.7):box(m,'vano_referencial',i,y-.04,1,1.4,.07,h,'glass')
m=model('01','Foro musical Amalaya','Identificación por rótulo. Patio, escenario y gradas aproximados; sin aforo inferido.')
block(m,'ala_izquierda',0,0,6,29,9,'pink');block(m,'ala_derecha',28,0,6,29,9,'pink');block(m,'escenario',6,23,22,6,11,'pink');block(m,'acceso',0,0,34,5,6,'pink')
for i in range(8):box(m,'grada',8,6+i*1.5,0,18,1.5,.4+i*.36,'gray')
box(m,'plataforma',7,21,0,20,3,2,'dark');windows(m,0,0,34,2.4)
m=model('02','Locales comerciales y oficina','Agrupación naranja al lado izquierdo de la plaza. Volúmenes superiores interpretados como oficinas; división exacta no legible.')
block(m,'locales_frente',0,0,29,7,4,'orange');block(m,'ala_izquierda',0,7,7,16,4,'orange');block(m,'ala_fondo',7,17,22,6,4,'orange');box(m,'oficina_A',8,16,4,8,7,4,'yellow');box(m,'oficina_B',20,12,4,9,10,3,'orange');windows(m,0,0,29,2.6)
m=model('03','Edificios mixtos vivienda y ensayo','Identificación por rótulo de tres niveles. Las alturas y particiones son esquemáticas.')
block(m,'cuerpo_A',0,0,11,12,9,'yellow');block(m,'cuerpo_B',11,2,17,12,9,'yellow');block(m,'conexion',-9,8,9,4,5,'orange')
# cilindro del remate visible
n=20;v=[[12+3*math.cos(i*2*math.pi/n),13+3*math.sin(i*2*math.pi/n),z] for z in [0,11] for i in range(n)];f=[list(range(n-1,-1,-1)),list(range(n,2*n))]+[[i,(i+1)%n,(i+1)%n+n,i+n] for i in range(n)];m['parts'].append({'name':'remate_curvo','v':v,'f':f,'c':colors['orange']})
m=model('04','Volumen de cubierta azul','Posible Museo de la Ciudad José Alberto Healy por proximidad del rótulo; correspondencia no confirmada.')
block(m,'cuerpo',0,0,23,10,5,'orange');box(m,'cubierta',-.6,-.6,5,24.2,11.2,.65,'blue');windows(m,0,0,23,2.5)
m=model('05','Tiendas y talleres creativos','Identificación por rótulo. Edificio en U con patio; aperturas esquemáticas.')
block(m,'frente',0,0,28,6,4.2,'orange');block(m,'lateral',21,6,7,19,4.2,'orange');block(m,'fondo',5,19,16,6,4.2,'orange');windows(m,0,0,28,2.8)
def parking(id,name):
 m=model(id,name,'Estacionamiento interpretado a partir del dibujo. Niveles, estructura y paneles son esquemáticos; no valida las 300 plazas indicadas para HEALY.')
 for z in [0,3,6,9]:box(m,'losa',0,0,z,28,22,.35,'gray')
 for x in [1,7.5,14,20.5,27]:
  for y in [1,10,21]:box(m,'columna',x,y,0,.5,.5,9,'gray')
 for z in [1,4,7]:
  box(m,'antepecho_frontal',0,0,z,28,.3,.65,'gray');box(m,'antepecho_posterior',0,21.7,z,28,.3,.65,'gray');box(m,'antepecho_lateral',0,0,z,.3,22,.65,'gray');box(m,'antepecho_lateral',27.7,0,z,.3,22,.65,'gray')
 for x in [2,13,25]:
  for y in [4,18]:box(m,'soporte_cubierta',x,y,9,.25,.25,2,'gray')
 for i in range(9):
  for j in range(7):box(m,'panel_cubierta',1+i*2.9,2+j*2.6,11,2.75,2.45,.12,'panel')
 return m
parking('06','Estacionamiento HEALY primer plano');parking('07','Estacionamiento segundo plano')
m=model('08','Conjunto amarillo al fondo','Uso no legible y conjunto recortado por el borde de la imagen. Reconstrucción parcial, con menor certeza.')
block(m,'barra_posterior',0,17,31,6,8,'yellow');block(m,'ala_lateral',24,0,7,17,8,'yellow');block(m,'ala_corta',10,0,6,10,6,'yellow');windows(m,24,0,7,3)
# Export geometría real y proyecciones de la misma malla.
def glb(m,path):
 positions=[];indices=[];materials=[];meshes=[];nodes=[];views=[];access=[];blob=bytearray()
 def add(data,target):
  while len(blob)%4:blob.append(0)
  off=len(blob);blob.extend(data);views.append({'buffer':0,'byteOffset':off,'byteLength':len(data),'target':target});return len(views)-1
 for p in m['parts']:
  v=np.array(p['v'],dtype=np.float32);v=v[:,[0,2,1]];v[:,2]*=-1
  ix=np.array([[f[0],f[i],f[i+1]] for f in p['f'] for i in range(1,len(f)-1)],dtype=np.uint32).flatten()
  a=add(v.tobytes(),34962);access.append({'bufferView':a,'componentType':5126,'count':len(v),'type':'VEC3','min':v.min(0).tolist(),'max':v.max(0).tolist()});ai=len(access)-1
  b=add(ix.tobytes(),34963);access.append({'bufferView':b,'componentType':5125,'count':len(ix),'type':'SCALAR'});bi=len(access)-1
  c=[int(p['c'][i:i+2],16)/255 for i in [1,3,5]];materials.append({'pbrMetallicRoughness':{'baseColorFactor':c+[1],'metallicFactor':0,'roughnessFactor':.85},'doubleSided':True})
  meshes.append({'name':p['name'],'primitives':[{'attributes':{'POSITION':ai},'indices':bi,'material':len(materials)-1}]});nodes.append({'mesh':len(meshes)-1,'name':p['name']})
 d={'asset':{'version':'2.0','generator':'Amalaya interpretacion volumetrica'},'scene':0,'scenes':[{'nodes':list(range(len(nodes)))}],'nodes':nodes,'meshes':meshes,'materials':materials,'buffers':[{'byteLength':len(blob)}],'bufferViews':views,'accessors':access,'extras':{'units':'arbitrary; not surveyed','note':m['note']}}
 j=json.dumps(d).encode();j+=b' '*((-len(j))%4);blob+=b'\0'*((-len(blob))%4)
 path.write_bytes(struct.pack('<III',0x46546c67,2,12+8+len(j)+8+len(blob))+struct.pack('<II',len(j),0x4e4f534a)+j+struct.pack('<II',len(blob),0x004e4942)+blob)
def project(m,az,el):
 a,e=np.radians([az,el]);r=np.array([math.cos(a),math.sin(a),0]);u=np.array([-math.sin(a)*math.sin(e),math.cos(a)*math.sin(e),math.cos(e)]);d=np.cross(r,u);faces=[]
 for p in m['parts']:
  v=np.array(p['v']);rgb=np.array([int(p['c'][i:i+2],16)/255 for i in [1,3,5]])
  for f in p['f']:
   pts=v[f];normal=np.cross(pts[1]-pts[0],pts[2]-pts[0]);normal=normal/(np.linalg.norm(normal) or 1);shade=.77+.23*abs(np.dot(normal,[.3,-.4,.866]));
   if np.dot(normal,d)<=0:continue
   polys=[pts]
   if len(pts)==4:
    polys=[]
    for i in range(2):
     for j in range(2):
      q=[]
      for t,s in [(i/2,j/2),((i+1)/2,j/2),((i+1)/2,(j+1)/2),(i/2,(j+1)/2)]:q.append(pts[0]*(1-t)*(1-s)+pts[1]*t*(1-s)+pts[2]*t*s+pts[3]*(1-t)*s)
      polys.append(np.array(q))
   for poly in polys:faces.append((np.mean(poly@d),np.c_[poly@r,poly@u],np.clip(rgb*shade,0,1)))
 return sorted(faces,key=lambda x:x[0])
def draw(ax,m,az,el):
 fs=project(m,az,el);ax.add_collection(PolyCollection([f[1] for f in fs],facecolors=[f[2] for f in fs],edgecolors=[f[2] for f in fs],linewidths=.3));ax.autoscale();ax.set_aspect('equal');ax.margins(.08);ax.axis('off')
views=[('iso_01',45,35.264),('iso_02',135,35.264),('iso_03',225,35.264),('iso_04',315,35.264),('alzado_A',0,0),('alzado_B',90,0),('alzado_C',180,0),('alzado_D',270,0),('azotea',0,90)]
for m in models:
 folder=P/(m['id']+'_'+m['name'].replace(' ','_'));folder.mkdir(exist_ok=True);glb(m,folder/'modelo.glb')
 lines=['# Unidades relativas; Z arriba. No usar como levantamiento medido.','mtllib modelo.mtl'];mtl=[];offset=1
 for i,p in enumerate(m['parts']):
  lines+=['o '+p['name']+'_'+str(i),'usemtl c'+str(i)]+['v '+' '.join(map(str,v)) for v in p['v']]+['f '+' '.join(str(j+offset) for j in f) for f in p['f']];offset+=len(p['v']);mtl+=['newmtl c'+str(i),'Kd '+' '.join(str(int(p['c'][j:j+2],16)/255) for j in [1,3,5])]
 (folder/'modelo.obj').write_text('\n'.join(lines));(folder/'modelo.mtl').write_text('\n'.join(mtl))
 fig,axes=plt.subplots(3,3,figsize=(12,10),facecolor='white');fig.suptitle(m['id']+' · '+m['name'],fontsize=17)
 for ax,(label,a,e) in zip(axes.flat,views):
  draw(ax,m,a,e);ax.set_title(label.replace('_',' '),fontsize=10)
  single,sa=plt.subplots(figsize=(7,7));draw(sa,m,a,e);single.savefig(folder/(label+'.png'),dpi=130,transparent=True,bbox_inches='tight');single.savefig(folder/(label+'.svg'),transparent=True,bbox_inches='tight');plt.close(single)
 fig.text(.5,.025,'RECONSTRUCCIÓN INTERPRETATIVA · Sin escala comprobada · Alzados A–D sin orientación geográfica',ha='center',fontsize=9)
 fig.savefig(folder/'lamina.png',dpi=120);plt.close(fig)
fig,axes=plt.subplots(2,4,figsize=(16,8));
for ax,m in zip(axes.flat,models):draw(ax,m,45,35.264);ax.set_title(m['id']+' · '+m['name'],fontsize=9)
fig.suptitle('AMALAYA / ZONA NÚCLEO — Catálogo de volúmenes interpretados',fontsize=18);fig.text(.5,.025,'Geometría aproximada de una sola imagen · Sin escala comprobada · 08 parcial',ha='center');fig.savefig(P/'Catalogo.png',dpi=130);plt.close(fig)
(P/'modelos.json').write_text(json.dumps(models,ensure_ascii=False))
print('Modelos y vistas exportados',len(models))
