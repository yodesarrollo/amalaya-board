import numpy as np,json,math
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
P=Path(__file__).parent;models=json.loads((P/'modelos.json').read_text());font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',18)
views=[('iso_01',45,35.264),('iso_02',135,35.264),('iso_03',225,35.264),('iso_04',315,35.264),('alzado_A',0,0),('alzado_B',90,0),('alzado_C',180,0),('alzado_D',270,0),('azotea',0,90)]
def render(m,az,el,N=700):
 a,e=np.radians([az,el]);r=np.array([math.cos(a),math.sin(a),0]);u=np.array([-math.sin(a)*math.sin(e),math.cos(a)*math.sin(e),math.cos(e)]);d=np.cross(r,u);M=np.array([r,u,d]).T;all=np.vstack([p['v'] for p in m['parts']])@M;lo=all.min(0);hi=all.max(0);scale=.88*N/max(hi[0]-lo[0],hi[1]-lo[1]);mid=(hi+lo)/2
 im=np.zeros((N,N,4),dtype=np.uint8);depth=np.full((N,N),-np.inf);svg=[]
 for p in m['parts']:
  world=np.array(p['v']);vv=world@M;vv[:,0]=(vv[:,0]-mid[0])*scale+N/2;vv[:,1]=N/2-(vv[:,1]-mid[1])*scale
  for f in p['f']:
   q=world[f];n=np.cross(q[1]-q[0],q[2]-q[0]);n=n/(np.linalg.norm(n) or 1)
   if n@d<=1e-8:continue
   rgb=np.array([int(p['c'][i:i+2],16) for i in [1,3,5]]);col=np.r_[np.clip(rgb*(.77+.23*abs(n@np.array([.3,-.4,.866]))),0,255),255].astype(np.uint8);v=vv[f]
   svg.append('<polygon points="'+' '.join(f'{x:.2f},{y:.2f}' for x,y,z in v)+'"/>')
   for k in range(1,len(v)-1):
    t=v[[0,k,k+1]];x0,y0=np.maximum(np.floor(t[:,:2].min(0)).astype(int),0);x1,y1=np.minimum(np.ceil(t[:,:2].max(0)).astype(int),N-1)
    if x1<x0 or y1<y0:continue
    xx,yy=np.meshgrid(np.arange(x0,x1+1)+.5,np.arange(y0,y1+1)+.5);ax,ay,az=t[0];bx,by,bz=t[1];cx,cy,cz=t[2];den=(by-cy)*(ax-cx)+(cx-bx)*(ay-cy)
    if abs(den)<1e-10:continue
    l1=((by-cy)*(xx-cx)+(cx-bx)*(yy-cy))/den;l2=((cy-ay)*(xx-cx)+(ax-cx)*(yy-cy))/den;l3=1-l1-l2;z=l1*az+l2*bz+l3*cz;reg=depth[y0:y1+1,x0:x1+1];mask=(l1>=-1e-8)&(l2>=-1e-8)&(l3>=-1e-8)&(z>=reg);reg[mask]=z[mask];im[y0:y1+1,x0:x1+1][mask]=col
 return Image.fromarray(im),'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 700 700"><g fill="none" stroke="#3a4850" stroke-width="0.65">'+''.join(svg)+'</g></svg>'
cat=Image.new('RGB',(1600,920),'white');dc=ImageDraw.Draw(cat);dc.text((35,20),'AMALAYA / Zona Núcleo · Modelos volumétricos aproximados',font=font,fill='#153a47')
for mi,m in enumerate(models):
 folder=next(P.glob(m['id']+'_*'));sheet=Image.new('RGB',(1500,1560),'white');ds=ImageDraw.Draw(sheet);ds.text((25,16),m['id']+' · '+m['name'],font=font,fill='#153a47')
 for vi,(label,a,e) in enumerate(views):
  im,svg=render(m,a,e);im.save(folder/(label+'.png'));(folder/(label+'.svg')).write_text(svg)
  thumb=im.resize((470,470));x=(vi%3)*500+15;y=(vi//3)*500+55;sheet.paste(thumb,(x,y),thumb);ds.text((x,y),label,font=font,fill='#153a47')
  if vi==0:
   thumb=im.resize((390,390));x=(mi%4)*400;y=(mi//4)*420+65;cat.paste(thumb,(x,y),thumb);dc.text((x+12,y+368),m['id']+' · '+m['name'][:29],font=font,fill='#153a47')
 ds.text((25,1530),'Sin escala comprobada · Caras ocultas interpretadas · SVG: líneas sin eliminación de ocultas',font=font,fill='#596773');sheet.save(folder/'lamina.png')
cat.save(P/'Catalogo.png')
with (P/'LEEME.txt').open('a') as f:f.write('\nVISTAS FINALES: render_vistas.py genera PNG con profundidad por píxel. Los SVG son proyecciones de líneas para calcar e incluyen líneas superpuestas/ocultas; no son planos ejecutivos. Ejecutarlo después de generar.py.\n')
print('Vistas con profundidad verificable completas')
