from pathlib import Path
import sys,os,json,math,csv,zipfile,shutil,xml.etree.ElementTree as ET
import numpy as np
from shapely.geometry import Polygon,LineString,Point,box,mapping,shape
from shapely.ops import transform,unary_union,polygonize
from pyproj import Transformer,CRS
import trimesh
from PIL import Image,ImageDraw,ImageFont
P=Path(__file__).resolve().parents[1]
ROOT=P.parent
DATE='2026-09-26'
ORIGIN=[-110.95477,29.07606]
fwd=Transformer.from_crs(4326,32612,always_xy=True);rev=Transformer.from_crs(32612,4326,always_xy=True)
OX,OY=fwd.transform(*ORIGIN)
def xy(lon,lat,z=None):
 x,y=fwd.transform(lon,lat);return (np.array(x)-OX,np.array(y)-OY)
def ll(x,y,z=None):return rev.transform(np.array(x)+OX,np.array(y)+OY)
def dump(path,obj):path.write_text(json.dumps(obj,ensure_ascii=False,indent=2))
def gj(features):return {'type':'FeatureCollection','features':features}
def feat(g,props):return {'type':'Feature','geometry':mapping(transform(ll,g)),'properties':props}
def localfeat(g,props):return {'type':'Feature','geometry':mapping(g),'properties':props}
# Core working area. This rectangle is an export extent, not project ownership.
BBOX=[-110.9585,29.0735,-110.951,29.079]
bound=transform(xy,box(*BBOX));xmin,ymin,xmax,ymax=bound.bounds
src=ET.parse(P/'fuentes/entorno.osm').getroot()
nodes={n.get('id'):(float(n.get('lon')),float(n.get('lat'))) for n in src.findall('node')}
ways={w.get('id'):w for w in src.findall('way')}
def tags(el):return {t.get('k'):t.get('v') for t in el.findall('tag')}
def pts(w):return [nodes[n.get('ref')] for n in w.findall('nd')]
def polyparts(g):
 if g.is_empty:return []
 if g.geom_type=='Polygon':return [g]
 if hasattr(g,'geoms'):return [p for q in g.geoms for p in polyparts(q)]
 return []
roads=[];buildings=[];parks=[];other=[]
for id,w in ways.items():
 t=tags(w);p=pts(w)
 if len(p)<2:continue
 prop={'id':'OSM_W'+id,'osm_type':'way','osm_id':id,'name':t.get('name',''),'source':'OpenStreetMap','download_date':DATE,'osm_timestamp':w.get('timestamp'),'tags':t,'status':'cartografiado; existencia actual no inspeccionada'}
 if 'highway' in t and t.get('area')!='yes':
  g=transform(xy,LineString(p)).intersection(bound)
  if not g.is_empty:
   width=14 if t['highway'] in ['primary','secondary'] else 3 if t['highway'] in ['footway','path','pedestrian','steps'] else 6 if t['highway']=='service' else 8
   prop.update({'width_m':width,'width_status':'estimada por tipo vial, no medida','kind':'road'});roads.append((g,prop))
 if p[0]!=p[-1] or len(p)<4:continue
 g=transform(xy,Polygon(p)).buffer(0).intersection(bound)
 if g.is_empty:continue
 if 'building' in t:
  height=6.;hs='altura ilustrativa 6 m; sin dato OSM'
  try:
   if t.get('height'):height=float(t['height'].replace('m','').strip());hs='height declarado en OSM; sin validación de campo'
   elif t.get('building:levels'):height=float(t['building:levels'])*3.;hs='niveles OSM × 3 m estimados por nivel'
  except ValueError:pass
  prop.update({'kind':'building','height_m':height,'height_status':hs});buildings.append((g,prop))
 elif t.get('leisure')=='park':prop['kind']='park';parks.append((g,prop))
 elif t.get('landuse')=='retail':prop['kind']='landuse';other.append((g,prop))
# Additional machine-detected footprints, kept separate from OSM.
ml=[];ml_excluded=[]
msfile=P/'fuentes/huellas_microsoft_raw.geojson'
if msfile.exists():
 osm_union=unary_union([g for g,p in buildings]).buffer(1)
 for f in json.loads(msfile.read_text())['features']:
  g=transform(xy,shape(f['geometry'])).buffer(0).intersection(bound);srcp=f.get('properties',{});row=srcp['source_row'];id='MS_023120210_'+str(row)
  if g.is_empty or g.area<9:continue
  overlap=g.intersection(osm_union).area/g.area
  if overlap>.15:
   ml_excluded.append({'id':id,'reason':'solape >15% con huella OSM ampliada 1 m; se prioriza OSM','overlap':round(overlap,4)});continue
  h=float(srcp.get('height',-1));hs='estimación de altura publicada por Microsoft; no medida' if h>0 else 'altura ilustrativa 6 m; proveedor sin estimación'
  if h<=0:h=6.
  prop={'id':id,'name':'Huella detectada '+str(row),'kind':'building_ml','source':'Microsoft Global ML Building Footprints','release':'2026-08-13','download_date':DATE,'height_m':h,'height_status':hs,'confidence':srcp.get('confidence',-1),'status':'detección automática en imágenes históricas; existencia y perímetro sin inspección','license':'CDLA-Permissive-2.0','source_row':row}
  ml.append((g,prop))
 dump(P/'datos/microsoft_excluidos_solape.json',ml_excluded)
# Roads-derived analytical blocks, no cadastral boundaries.
net=unary_union([g for g,p in roads if p['tags']['highway'] not in ['footway','path','steps','service']])
blocks=[]
for q in polygonize(net):
 if q.area<250 or q.area>150000:continue
 for g in polyparts(q.buffer(-4).intersection(bound)):
  if g.area<100:continue
  blocks.append(g)
blocks.sort(key=lambda g:(-round(g.centroid.y/30),g.centroid.x))
blockpairs=[(g,{'id':f'M{i+1:02}','name':f'Manzana analítica {i+1:02}','kind':'block','source':'ejes OSM; poligonización y retranqueo uniforme 4 m','status':'borde aproximado, no catastral','area_approx_m2':round(g.area)}) for i,g in enumerate(blocks)]
plaza=next(g for g,p in parks if p['name']=='Plaza Hidalgo')
# Preserve both earlier deliverables and the source images.
# Las referencias originales se incluyen en el paquete; no se redescargan.
zones=json.loads((P/'referencias/Mapas_Amalaya/zonas.json').read_text())['zonas']
# Geographic hypothesis of the perspective drawing anchored solely on the plaza corners.
spts=np.array([[522,385],[838,327],[862,350],[539,406]],float)
gpts=np.array([xy(*v) for v in [[-110.9554977,29.0760797],[-110.9540713,29.0761874],[-110.9540551,29.0760228],[-110.9554814,29.0759151]]])
A=[];B=[]
for (u,v),(x,y) in zip(spts,gpts):A.extend([[u,v,1,0,0,0,-x*u,-x*v],[0,0,0,u,v,1,-y*u,-y*v]]);B.extend([x,y])
h=np.r_[np.linalg.solve(np.array(A),B),1].reshape(3,3)
def hp(p):
 v=np.c_[np.array(p),np.ones(len(p))]@h.T;return v[:,:2]/v[:,2,None]
proposals=[]
for z in zones:
 g=Polygon(hp(z['poligono_px'])).buffer(0);prop={'id':z['id'],'name':z['nombre'],'kind':'proposal_zone','color':z['color'],'source':'lámina perspectiva del usuario, plan 1','registration':'hipótesis por cuatro esquinas de Plaza Hidalgo; sin control independiente','status':'propuesta interpretada, no predio ni construcción existente','note':z['nota']}
 if z['id']=='Z02':g=plaza;prop['registration']='sustituida por contorno OSM de Plaza Hidalgo';prop['status']='espacio público cartografiado'
 proposals.append((g,prop))
# District screenshot: coarse affine registration from three manually identified landmarks.
control=[{'id':'C1','landmark':'Mercado Municipal, centro aproximado','px':[579,217],'lonlat':[-110.9527129,29.078394]}, {'id':'C2','landmark':'Plaza Zaragoza, centro aproximado','px':[216,419],'lonlat':[-110.9590995,29.0751434]}, {'id':'C3','landmark':'Plaza Hidalgo, monumento/centro aproximado','px':[465,365],'lonlat':ORIGIN}]
T=np.linalg.solve(np.c_[[v['px'] for v in control],np.ones(3)],np.array([xy(*v['lonlat']) for v in control]))
redpx=[[416,338],[450,331],[478,320],[475,298],[572,279],[589,370],[532,386],[537,417],[528,443],[525,478],[431,478],[432,453],[420,449],[396,453],[389,448],[386,428],[411,420],[416,417],[412,370]]
def affine(p):return np.c_[p,np.ones(len(p))]@T
nucleus=Polygon(affine(redpx)).buffer(0)
# Yellow edge remains open where the supplied slide hides/crops it.
yellowpx=[[760,277],[745,281],[738,277],[734,246],[614,271],[608,233],[626,228],[627,193],[583,199],[582,154],[568,154],[564,99],[559,96],[560,79],[548,79],[548,69],[527,69],[527,104],[521,124],[527,152],[530,173],[538,175],[539,199],[522,202],[527,242]]
yellow2=[[447,246],[409,255],[417,338],[412,370],[416,417],[386,428],[389,448],[396,453],[420,449],[432,453],[431,478],[429,559],[400,561],[386,570],[207,584],[195,461],[165,461],[157,386],[184,379],[195,371],[193,361],[211,356],[218,329],[229,323],[211,314],[216,305],[209,302],[214,294],[260,316],[274,307],[302,302],[291,250],[357,235],[355,215],[420,210]]
district=[(nucleus,{'id':'A01','name':'Zona núcleo de la lámina territorial','kind':'district','color':'#dc6655','status':'digitalización interpretativa; ajuste geográfico provisional','source':'lámina territorial del usuario','note':'tramo superior parcialmente oculto por flecha; interpolado. Tres controles manuales, sin validación independiente.'})]
traces=[(LineString(affine(yellowpx)),{'id':'A02a','name':'Borde amarillo norte–este visible','kind':'trace','status':'abierto; no inferir área ni cerrar automáticamente'}),(LineString(affine(yellow2)),{'id':'A02b','name':'Borde amarillo occidental visible','kind':'trace','status':'abierto; segmentos ocultos impiden confirmar cierre'})]
layers={'huellas_detectadas_microsoft':ml,'calles':roads,'edificios':buildings,'plazas':parks,'manzanas_analiticas':blockpairs,'propuesta_hipotesis':proposals,'nucleo_hipotesis':district,'borde_amarillo_abierto':traces,'usos_osm':other,'ambito_exportacion':[(bound,{'id':'EXT','kind':'extent','name':'Ámbito operativo de exportación','status':'rectángulo de trabajo; no límite del proyecto'})]}
for name,pairs in layers.items():dump(P/'datos'/f'{name}.geojson',gj([feat(g,p) for g,p in pairs]))
dump(P/'datos/geometria_local.json',{'crs':'EPSG:32612 minus origin','origin_utm':[OX,OY],'layers':{k:gj([localfeat(g,p) for g,p in v]) for k,v in layers.items()}})
dump(P/'datos/registro_laminas.json',{'perspectiva':{'image_size':[1280,589],'image_control_points':spts.tolist(),'local_control_points':gpts.tolist(),'homography_px_to_local':h.tolist(),'independent_validation':False,'warning':'los polígonos de imagen incluyen caras y cubiertas: NO son huellas ortogonales medidas'},'territorial':{'image_size':[1280,589],'control_points':control,'affine_px_to_local':T.tolist(),'independent_validation':False,'rms_independent_m':None,'warning':'Tres puntos interpolados no permiten estimar exactitud; no usar para deslindes ni cálculo de adquisición de predios.'}})
# Local mesh data and editable glTF.
objects=[]
def add_mesh(id,name,kind,mesh,color,metadata):
 if len(mesh.faces)==0:return
 mesh.remove_unreferenced_vertices();rgb=[int(color[i:i+2],16) for i in [1,3,5]];mesh.visual.vertex_colors=rgb+[255]
 objects.append({'id':id,'name':name,'kind':kind,'color':color,'metadata':metadata,'vertices':np.round(mesh.vertices,4).tolist(),'faces':mesh.faces.tolist()})
def extrude(id,name,kind,g,height,color,metadata,z=0):
 meshes=[]
 for q in polyparts(g):
  if q.area<.05:continue
  m=trimesh.creation.extrude_polygon(q,height,engine='earcut');m.apply_translation([0,0,z]);meshes.append(m)
 if meshes:add_mesh(id,name,kind,trimesh.util.concatenate(meshes),color,metadata)
extrude('BASE','Plano de apoyo, sin topografía','ground',bound,.25,'#e8e3d8',{'terrain':'plano de trabajo; sin elevaciones reales'},-.25)
for g,p in blockpairs:extrude(p['id'],p['name'],'block',g,.06,'#d8d0c1',p)
for i,(g,p) in enumerate(roads):extrude(p['id'],p['name'] or 'Vía sin nombre','road',g.buffer(p['width_m']/2,cap_style=2,join_style=2).intersection(bound),.04,'#adb4b3',p,.065)
for g,p in parks:extrude(p['id'],p['name'],'park',g,.12,'#82a58b',p,.09)
for g,p in buildings:extrude(p['id'],p['name'] or 'Edificio OSM '+p['osm_id'],'building',g,p['height_m'],'#b9c5c5',p,.1)
for g,p in ml:extrude(p['id'],p['name'],'building_ml',g,p['height_m'],'#c5bdb1',p,.1)
for g,p in proposals:extrude(p['id']+'_mask',p['name'],'zone',g,.15,p['color'],p,.16)
# Place previous models in hypothesis zones using an explicit approximate uniform fit.
mods=json.loads(zipfile.ZipFile(P/'referencias/Amalaya_3D_original.zip').read('Amalaya_3D/modelos.json'));crosswalk={'01':'Z01','02':'Z03','03':'Z04','04':'Z05','05':'Z06','06':'Z07','07':'Z08','08':'Z09'}
east=(gpts[1]-gpts[0]);east/=np.linalg.norm(east);north=np.array([-east[1],east[0]]);rot=np.c_[east,north]
placements=[]
for mod in mods:
 zid=crosswalk[mod['id']];g,p=next((g,p) for g,p in proposals if p['id']==zid);coords=np.array(g.exterior.coords)@rot;glo=coords.min(0);ghi=coords.max(0);v=np.vstack([p['v'] for p in mod['parts']]);vlo=v.min(0);vhi=v.max(0);scale=.85*min((ghi-glo)/(vhi-vlo)[:2]);center=(glo+ghi)/2
 meshes=[]
 for j,part in enumerate(mod['parts']):
  vv=np.array(part['v'],float);vv[:,:2]=((vv[:,:2]-(vlo+vhi)[:2]/2)*scale+center)@rot.T;vv[:,2]=vv[:,2]*scale+.4
  faces=[[f[0],f[k],f[k+1]] for f in part['f'] for k in range(1,len(f)-1)]
  m=trimesh.Trimesh(vertices=vv,faces=faces,process=False);add_mesh('P'+mod['id']+'_'+str(j),mod['name'],'proposal',m,part['c'],{'zone_id':zid,'module_id':mod['id'],'placement_status':'hipótesis no validada','height_status':'escalada proporcionalmente, no medida'})
 placements.append({'module_id':mod['id'],'zone_id':zid,'scale_assumed':float(scale),'rotation_deg':float(np.degrees(math.atan2(east[1],east[0]))),'local_center_m':(center@rot.T).tolist(),'status':'aproximación para maqueta; no ajuste predial'})
dump(P/'datos/colocacion_modulos.json',placements)
# Export GLB Y up; coordinates metadata retains ENU local mapping.
def scene_export(filename,allowed):
 s=trimesh.Scene()
 for ob in objects:
  if ob['kind'] not in allowed:continue
  v=np.array(ob['vertices']);v=v[:,[0,2,1]];v[:,2]*=-1
  m=trimesh.Trimesh(vertices=v,faces=ob['faces'],process=False);m.visual.vertex_colors=[int(ob['color'][i:i+2],16) for i in [1,3,5]]+[255];m.metadata=ob['metadata']
  s.add_geometry(m,node_name=ob['id'],geom_name=ob['id'])
 (P/'modelos'/filename).write_bytes(s.export(file_type='glb'))
scene_export('Base_urbana_OSM.glb',{'ground','road','block','park','building'})
scene_export('Base_urbana_completa.glb',{'ground','road','block','park','building','building_ml'})
scene_export('Amalaya_colocacion_hipotetica.glb',{'proposal'})
scene_export('Tablero_comparativo.glb',{'ground','road','block','park','building','building_ml','proposal'})
# Each mapped building exported separately, local common origin preserved.
(P/'modelos/edificios_individuales').mkdir(exist_ok=True)
for ob in objects:
 if ob['kind'] not in ['building','building_ml']:continue
 m=trimesh.Trimesh(vertices=ob['vertices'],faces=ob['faces'],process=False);(P/'modelos/edificios_individuales'/f'{ob["id"]}.obj').write_text(m.export(file_type='obj'))
# North-up orthographic maps and aligned masks, UTM world files.
W,H=1800,1500;left,bottom,right,top=bound.bounds;res=max((right-left)/W,(top-bottom)/H);right=left+res*W;bottom=top-res*H
fontpath='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
font=ImageFont.truetype(fontpath,20);small=ImageFont.truetype(fontpath,15);titlefont=ImageFont.truetype(fontpath,30)
def screen(x,y):return ((x-left)/res,(top-y)/res)
def coords_svg(g):
 rings=[]
 for q in polyparts(g):
  for ring in [q.exterior,*q.interiors]:rings.append('M '+' L '.join(f'{screen(x,y)[0]:.2f},{screen(x,y)[1]:.2f}' for x,y in ring.coords)+' Z')
 return ' '.join(rings)
def paint(im,g,fill,outline=None,width=2):
 mm=Image.new('L',im.size,0);md=ImageDraw.Draw(mm)
 for q in polyparts(g):
  md.polygon([screen(x,y) for x,y in q.exterior.coords],fill=255)
  for hole in q.interiors:md.polygon([screen(x,y) for x,y in hole.coords],fill=0)
 im.paste(fill,(0,0,*im.size),mm)
 if outline:
  dr=ImageDraw.Draw(im)
  for q in polyparts(g):dr.line([screen(x,y) for x,y in q.exterior.coords],fill=outline,width=width)
def saveworld(path):
 path.with_suffix('.pgw').write_text('\n'.join(map(str,[res,0,0,-res,left+OX+res/2,top+OY-res/2])))
 path.with_suffix('.prj').write_text(CRS.from_epsg(32612).to_wkt())
def mask(g,id,color):
 folder=P/'mascaras';im=Image.new('L',(W,H),0);paint(im,g,255);im.save(folder/(id+'_binaria.png'));saveworld(folder/(id+'_binaria.png'))
 alpha=Image.new('RGBA',(W,H),color);alpha.putalpha(im);alpha.save(folder/(id+'_alpha.png'));saveworld(folder/(id+'_alpha.png'))
 (folder/(id+'.svg')).write_text(f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}"><path d="{coords_svg(g)}" fill="{color}" fill-rule="evenodd"/></svg>')
for g,p in blockpairs+proposals+district:mask(g,p['id'],p.get('color','#a7b9bd'))
mask(plaza,'Plaza_Hidalgo_OSM','#82a58b')
# 01 map without typography suitable as texture; 02 plan with IDs; 03 proposal; 04 district.
base=Image.new('RGBA',(W,H),'#eeeae2')
for g,p in blockpairs:paint(base,g,'#ded6c9','#c4bba8')
for g,p in roads:paint(base,g.buffer(p['width_m']/2,cap_style=2,join_style=2),'#bfc5c4')
for g,p in parks:paint(base,g,'#a9c5a9','#688874')
for g,p in ml:paint(base,g,'#cfc5b7','#a19484')
for g,p in buildings:paint(base,g,'#bac9ce','#6b8590')
base.save(P/'mapas/00_base_textura.png');saveworld(P/'mapas/00_base_textura.png')
# Editable source map SVG, same canvas.
svg=[f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}"><rect width="100%" height="100%" fill="#eeeae2"/>']
for pairs,col in [(blockpairs,'#ded6c9'),(parks,'#a9c5a9'),(ml,'#cfc5b7'),(buildings,'#bac9ce')]:
 for g,p in pairs:svg.append(f'<path id="{p["id"]}" d="{coords_svg(g)}" fill="{col}" stroke="#89979a" stroke-width="1" fill-rule="evenodd"/>')
for g,p in roads:
 for line in ([g] if g.geom_type=='LineString' else list(g.geoms)):
  svg.append('<polyline points="'+' '.join(f'{screen(x,y)[0]:.2f},{screen(x,y)[1]:.2f}' for x,y in line.coords)+f'" fill="none" stroke="#bfc5c4" stroke-width="{p["width_m"]/res:.2f}"/>')
svg.append('</svg>');(P/'mapas/00_base_vector.svg').write_text(''.join(svg))
def legend(im,title,subtitle):
 d=ImageDraw.Draw(im);d.rectangle((20,20,W-20,100),fill='#143e49');d.text((40,32),title,font=titlefont,fill='white');d.text((40,72),subtitle,font=small,fill='#d3e5e7')
 d.rectangle((20,H-66,W-20,H-20),fill='#ffffff');d.text((34,H-58),'© OpenStreetMap contributors / ODbL · Microsoft Building Footprints / CDLA 2.0 · 26/09/2026 · Sin levantamiento',font=small,fill='#27424a')
 d.line((W-85,180,W-85,115),fill='#143e49',width=4);d.polygon([(W-85,107),(W-95,129),(W-75,129)],fill='#143e49');d.text((W-94,183),'N',font=font,fill='#143e49')
 length=100/res;d.rectangle((45,H-100,45+length,H-91),fill='#143e49');d.text((45,H-129),'100 m · norte de cuadrícula UTM',font=small,fill='#143e49')
def labels(im,kind='base'):
 d=ImageDraw.Draw(im)
 if kind=='base':
  for g,p in blockpairs:
   x,y=screen(g.representative_point().x,g.representative_point().y);d.text((x,y),p['id'],font=font,fill='#746954',anchor='mm')
  names=['Plaza Hidalgo','Instituto Sonorense de Cultura','Edificio Banxico','Palacio Municipal de Hermosillo','Leona Vicario']
  for g,p in parks+buildings:
   if p['name'] in names:
    x,y=screen(g.centroid.x,g.centroid.y);txt=p['name'].replace('Palacio Municipal de Hermosillo','Palacio Municipal').replace('Instituto Sonorense de Cultura','ISC');d.text((x,y),txt,font=small,fill='#143e49',stroke_width=2,stroke_fill='white',anchor='mm')
  used=set()
  for g,p in roads:
   name=p['name'];geom=g if g.geom_type=='LineString' else max(g.geoms,key=lambda q:q.length)
   if name in used or geom.length<120 or not name:continue
   used.add(name);v=geom.interpolate(.45,normalized=True);x,y=screen(v.x,v.y)
   if y>130 and y<H-150:d.text((x,y),name,font=small,fill='#3c555b',stroke_width=2,stroke_fill='#eeeae2',anchor='mm')
for filename,title,sub,overlay in [('01_ubicacion_y_manzanas','Ubicación / Plaza Hidalgo — Hermosillo','M: manzanas analíticas derivadas de ejes viales; no son predios catastrales',[]),('02_zonas_propuesta','Zona núcleo / Correspondencia Z01–Z10','Colocación geográfica provisional de la lámina en perspectiva; requiere validación',proposals),('03_distrito_interpretado','Distrito / Perímetro de la lámina territorial','A01: núcleo interpretado. Borde amarillo abierto, sin cierre confirmado.',district)]:
 im=base.copy()
 for g,p in overlay:
  layer=Image.new('RGBA',(W,H));paint(layer,g,p.get('color','#dc6655')+'70',p.get('color','#dc6655'),4);im=Image.alpha_composite(im,layer);d=ImageDraw.Draw(im);x,y=screen(g.centroid.x,g.centroid.y);d.text((x,y),p['id'],font=font,fill='#132f3a',stroke_width=3,stroke_fill='white',anchor='mm')
 if filename.startswith('03'):
  d=ImageDraw.Draw(im)
  for g,p in traces:d.line([screen(x,y) for x,y in g.coords],fill='#c69126',width=7)
 else:labels(im,'base' if not overlay else 'zones')
 legend(im,title,sub);im.convert('RGB').save(P/'mapas'/f'{filename}.png');saveworld(P/'mapas'/f'{filename}.png')
# Machine-readable ledger and handoff metadata.
with (P/'datos/inventario.csv').open('w',newline='') as f:
 w=csv.writer(f);w.writerow(['id','name','kind','source','height_m','height_status','status'])
 for pairs in layers.values():
  for g,p in pairs:w.writerow([p.get(k,'') for k in ['id','name','kind','source','height_m','height_status','status']])
config={'title':'Amalaya · Plaza Hidalgo','origin_wgs84':ORIGIN,'origin_utm':[OX,OY],'projected_crs':'EPSG:32612','local_axes':'X este de cuadrícula; Y norte de cuadrícula; Z arriba, metros','glb_axes':'X este, Y arriba, Z sur; metros','extent_wgs84':BBOX,'map_extent_utm':[left+OX,bottom+OY,right+OX,top+OY],'map_resolution_m_per_pixel':res,'map_size':[W,H],'counts':{'buildings':len(buildings),'buildings_ml':len(ml),'buildings_total':len(buildings)+len(ml),'ml_excluded_overlap':len(ml_excluded),'roads':len(roads),'parks':len(parks),'blocks':len(blockpairs),'proposal_zones':len(proposals),'modules':len(mods)},'limits':['OSM incompleto; ausencias no equivalen a lotes baldíos','Alturas ilustrativas salvo niveles etiquetados; ningún edificio medido','Suelo plano: Cerro de la Campana no reconstruido','Propuesta colocada por hipótesis; sin límites catastrales','No es réplica fotorealista ni levantamiento topográfico'],'attribution':'© OpenStreetMap contributors · ODbL; Microsoft Global ML Building Footprints · CDLA Permissive 2.0','source_date':DATE}
dump(P/'datos/configuracion.json',config);dump(P/'datos/escena.json',{'config':config,'objects':objects,'zones':[localfeat(g,p) for g,p in proposals],'blocks':[localfeat(g,p) for g,p in blockpairs]})
print(json.dumps(config['counts']))
