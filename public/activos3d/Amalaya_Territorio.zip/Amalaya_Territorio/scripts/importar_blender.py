"""Abrir en Blender > Scripting > Text > Open > Run Script.
No borra objetos existentes. Importa en una colección nueva. Guardar .blend manualmente.
Script preparado; no ejecutado en Blender durante esta entrega.
"""
import bpy,json
from pathlib import Path
try:BASE=Path(__file__).resolve().parents[1]
except NameError:BASE=Path(bpy.data.filepath).parent
scene_path=BASE/'datos/escena.json'
if not scene_path.exists():raise FileNotFoundError('Ubica este script dentro de scripts/, junto a la carpeta datos del paquete.')
d=json.loads(scene_path.read_text());root=bpy.data.collections.new('AMALAYA_ATLAS');bpy.context.scene.collection.children.link(root);groups={}
for rec in d['objects']:
 kind=rec['kind']
 if kind not in groups:
  groups[kind]=bpy.data.collections.new(kind);root.children.link(groups[kind]);groups[kind].hide_render=kind in ['proposal','zone'];groups[kind].hide_viewport=kind in ['proposal','zone']
 mesh=bpy.data.meshes.new(rec['id']);mesh.from_pydata(rec['vertices'],[],rec['faces']);mesh.update();obj=bpy.data.objects.new(rec['id']+' '+rec['name'],mesh);groups[kind].objects.link(obj)
 mat=bpy.data.materials.new(rec['id']);c=rec['color'];mat.diffuse_color=tuple(int(c[i:i+2],16)/255 for i in [1,3,5])+(1,);obj.data.materials.append(mat)
 obj['fuente_y_estado']=json.dumps(rec['metadata'],ensure_ascii=False);obj['id_atlas']=rec['id']
bpy.context.scene.unit_settings.system='METRIC';bpy.context.scene.unit_settings.scale_length=1
root['origin_WGS84']=str(d['config']['origin_wgs84']);root['origin_UTM']=str(d['config']['origin_utm']);root['crs']='EPSG:32612 menos origen';print('AMALAYA importado. Activar proposal para ver la hipótesis. Guardar el archivo .blend.')
