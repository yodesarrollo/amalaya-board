from pathlib import Path
import json
P=Path(__file__).resolve().parents[1];d=json.loads((P/'datos/geometria_local.json').read_text());lines=['0','SECTION','2','HEADER','9','$ACADVER','1','AC1009','0','ENDSEC','0','SECTION','2','ENTITIES']
def line(coords,layer,closed):
 lines.extend(['0','POLYLINE','8',layer,'66','1','70','1' if closed else '0'])
 for x,y,*_ in coords:lines.extend(['0','VERTEX','8',layer,'10',str(x),'20',str(y),'30','0'])
 lines.extend(['0','SEQEND','8',layer])
for key,col in d['layers'].items():
 for f in col['features']:
  g=f['geometry'];typ=g['type'];c=g['coordinates'];layer=f['properties']['id']
  if typ=='Polygon':
   for ring in c:line(ring,layer,True)
  elif typ=='MultiPolygon':
   for poly in c:
    for ring in poly:line(ring,layer,True)
  elif typ=='LineString':line(c,layer,False)
  elif typ=='MultiLineString':
   for ring in c:line(ring,layer,False)
lines.extend(['0','ENDSEC','0','EOF']);(P/'datos/Base_y_zonas_local_m.dxf').write_text('\n'.join(lines)+'\n')
