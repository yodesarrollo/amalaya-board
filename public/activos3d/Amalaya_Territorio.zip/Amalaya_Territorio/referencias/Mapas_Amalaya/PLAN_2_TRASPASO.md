# Amalaya: reconstrucción urbana y traspaso

## Objetivo
Crear un tablero editable del entorno del bulevar Hidalgo / Plaza Hidalgo, Hermosillo, y colocar por separado la propuesta Amalaya. El usuario confirmó bulevar Hidalgo. No se ha establecido el perímetro geográfico exacto ni su correspondencia predio por predio.

## Entregado: plan 1
10 zonas interpretativas en coordenadas de la imagen, máscaras PNG/SVG, mapa de colores, contornos, visor HTML, vértices JSON. Son envolventes funcionales en perspectiva, no huellas de suelo. La única base inferior entregada es referencia.jpeg. No hay mapa cenital ni georreferenciación. Conservar los ID Z01–Z10.

## Plan 2 recomendado
1. Localizar Plaza Hidalgo y su conexión con bulevar Hidalgo / Álvaro Obregón en cartografía actual. Contrastar orientación, esquinas y al menos tres puntos reconocibles con la lámina. No inventar coordenadas.
2. Fijar perímetro con coordenadas WGS84 y origen local en metros. Documentar CRS, fecha, norte y escala.
3. Obtener huellas y calles de OpenStreetMap u otra fuente autorizada. Verificar cobertura; campos faltantes de altura siguen siendo estimaciones.
4. Construir base editable en Blender; separar terreno, calles, manzanas, construcciones existentes y propuesta Amalaya. No interpretar los volúmenes propuestos como edificios existentes.
5. Modelar fachadas clave con fotografías propias/autorizadas y medidas disponibles. Street View no garantiza una reconstrucción automática precisa ni derechos de extracción.
6. Exportar GLB por edificio, escena global, polígonos geográficos, máscaras cenitales y ficha por objeto: ID, fuente, fecha, precisión, altura medida/estimada, estado existente/propuesto.
7. Probar en Unreal si se requiere recorrido con colisiones; en visor web si se prioriza compartir y seleccionar módulos.

## Alternativa visual
Cesium for Unreal permite transmitir Google Photorealistic 3D Tiles. Pendiente comprobar cobertura local, antigüedad, cuenta y condiciones de uso. No equivale a obtener un paquete offline libremente redistribuible ni edificios independientes. Consultar atribución y restricciones de almacenamiento antes de elegir esa ruta.

## Referencias verificadas en web
- Tutorial YouTube Blender OSM, Nicko16, enlazado por documentación oficial Blosm: https://www.youtube.com/watch?v=Thx08Q4etVc
- Documentación Blosm: https://github.com/vvoovv/blosm/wiki/Documentation
- Demostración YouTube Cesium and the Google Maps Platform: https://www.youtube.com/watch?v=EWSSHoGGCGQ
- Guía oficial Cesium: https://cesium.com/learn/unreal/unreal-photorealistic-3d-tiles/
- Google, políticas de Map Tiles: https://developers.google.com/maps/documentation/tile/policies
- Noticia de 28 agosto 2026 sobre demolición junto a Plaza Hidalgo: https://www.elimparcial.com/son/hermosillo/2026/08/28/demuelen-antiguo-edificio-de-la-procuraduria-en-hermosillo-para-mejorar-la-distribucion-vial/

Se localizaron videos y se contrastó el método con documentación. No se revisaron los videos completos ni se probó Cesium/Unreal en esta sesión.

## Pendientes explícitos
Correspondencia predial exacta, identificación del volumen azul y del conjunto amarillo, escala y alturas reales, cobertura Google 3D local, datos OSM locales, estado de obras al día, validación de máscaras sobre planta cenital. El siguiente agente debe resolver estos puntos antes de etiquetar el resultado como levantamiento real.
