# Inventario de correspondencia

| Zona | Módulo 3D original | Nombre | Estado |
|---|---|---|---|
| Z01 | 01 | Foro musical Amalaya | Hipótesis, sin confirmación predial |
| Z02 | Plaza OSM | Plaza Hidalgo | Contorno OSM |
| Z03 | 02 | Locales y oficinas | Hipótesis, sin confirmación predial |
| Z04 | 03 | Vivienda y estudios de ensayo | Hipótesis, sin confirmación predial |
| Z05 | 04 | Volumen azul / referencia al museo | Hipótesis, sin confirmación predial |
| Z06 | 05 | Tiendas y talleres creativos | Hipótesis, sin confirmación predial |
| Z07 | 06 | Estacionamiento frontal HEALY | Hipótesis, sin confirmación predial |
| Z08 | 07 | Estacionamiento posterior aparente | Hipótesis, sin confirmación predial |
| Z09 | 08 | Conjunto amarillo recortado | Hipótesis, sin confirmación predial |
| Z10 | Sin módulo: sin detalle suficiente | Volúmenes posteriores / transición | Hipótesis, sin confirmación predial |