# Amalaya — atlas territorial y maqueta geográfica

## Resultado y alcance
Este paquete permite estudiar y reutilizar el entorno de Plaza Hidalgo, Hermosillo. Combina cartografía abierta con dos láminas aportadas por el usuario y los ocho módulos 3D preparados anteriormente. Incluye mapa cenital, máscaras alineadas, geometrías geográficas, escena 3D y visor offline con modo de recorrido.

No es un levantamiento topográfico, catastral, fotogramétrico ni una réplica fotorealista. No se han medido alturas ni fachadas, no hay interiores, y el suelo del modelo es plano. Un edificio sin registro en una fuente no implica que el predio esté vacío. No se pueden deducir propiedad, disponibilidad, uso autorizado ni estado constructivo de la propuesta a partir de estas láminas.

## Identificación confirmada
La ficha de México es Cultura sitúa Plaza Hidalgo en Álvaro Obregón, entre José María Yáñez y Garmendia. El contorno OSM usado es way 308982539. El origen local se fijó en el monumento Miguel Hidalgo, cerca de 29.07606 N, -110.95477 O. La conexión al oeste es el bulevar Miguel Hidalgo y Costilla; el ámbito de trabajo también incluye Rosales/Pino Suárez, Serdán, Sufragio Efectivo y el borde del Cerro de la Campana.

Fuentes de ubicación:
- https://mexicoescultura.com/recinto/67213/plaza-hidalgosonora.html
- https://www.openstreetmap.org/way/308982539
- https://www.openstreetmap.org/node/6219440831

## Qué significa cada geometría
| Capa | Procedencia | Uso admisible en esta entrega |
|---|---|---|
| Calles | Ejes OSM descargados | Posición de referencia. Anchos asumidos por tipo de vía. |
| Edificios OSM | Polígonos cartografiados | Huellas de referencia; alturas de 6 m ilustrativas salvo niveles etiquetados. |
| Plazas | Contornos OSM | Referencia de espacios públicos cartografiados. |
| M01… | Poligonización de ejes, con retranqueo uniforme de 4 m | Manzanas analíticas; no predios ni linderos catastrales. |
| Z01–Z10 | Envolventes de la lámina en perspectiva | Correspondencia de diseño, con colocación geográfica hipotética. |
| A01 | Perímetro rojo digitalizado de la lámina territorial | Núcleo aproximado para discusión, sin verificación de deslinde. |
| A02a/A02b | Segmentos visibles del borde amarillo | Líneas abiertas; no se cierra ni calcula su superficie total. |

En Z02 se usa directamente el contorno cartográfico de Plaza Hidalgo. Los otros Z incluyen proyecciones de cubiertas y caras del dibujo: NO son huellas de suelo medidas. El ajuste usa cuatro esquinas de una misma plaza, sin puntos independientes de comprobación. Es insuficiente para situar edificios sobre predios con precisión. La transformación y sus puntos están documentados, no ocultos.

A01 se ajustó mediante tres hitos identificados manualmente en la segunda imagen: Mercado Municipal, Plaza Zaragoza y Plaza Hidalgo. Tres puntos permiten interpolar una transformación afín, pero no demostrar exactitud. No se reporta RMSE inventado. La flecha y los textos ocultan partes de la imagen y del borde; el segmento superior rojo se interpola. No usar esta capa para compra de terrenos, superficies legales ni replanteo.

## Coordenadas y unidades
- GeoJSON: WGS84 / EPSG:4326, orden longitud-latitud.
- Modelo local: UTM zona 12N / EPSG:32612 menos el origen UTM almacenado en `datos/configuracion.json`.
- JSON y OBJ: X este de cuadrícula, Y norte de cuadrícula, Z arriba, metros.
- GLB: X este, Y arriba, Z sur, metros.
- PNG: misma extensión y resolución dentro de `mapas/` y `mascaras/`. Los archivos PGW contienen coordenadas UTM absolutas del centro de píxel. Mantener juntos PNG, PGW y PRJ al importarlos a un SIG.
- Las máscaras del plan 1, dentro de `referencias/Mapas_Amalaya/`, permanecen en píxeles de la imagen en perspectiva; NO confundirlas con las nuevas máscaras cenitales.
- El DXF está en metros locales y conserva las capas por ID; no contiene anotaciones de cotas medidas.

## Usar la entrega
1. Extraer todo el ZIP. Abrir `Abrir_Amalaya.html` en un navegador con WebGL. No requiere internet ni credenciales.
2. Modo Maqueta 3D: arrastrar para orbitar, rueda para zoom, botón derecho para desplazar. Seleccionar objetos para consultar procedencia.
3. Modo Planta: vista superior con norte de cuadrícula arriba. Giro de 90° y captura de imagen disponibles.
4. Modo Recorrido: WASD o flechas para desplazarse, arrastrar para mirar, Shift para acelerar y Esc para volver. Es una maqueta con suelo plano. La colisión básica usa las huellas cartografiadas visibles; no valida pendientes, escaleras ni colisiones de la propuesta.
5. Activar o desactivar edificios y propuesta para comparar. El visor no presupone demoliciones. Puede haber solapes entre ambas capas.
6. Usar `modelos/Base_urbana_completa.glb` para la base y `modelos/Amalaya_colocacion_hipotetica.glb` para la propuesta. Ambos comparten origen.
7. Los archivos de módulos anteriores, con fachadas y azoteas, están en `referencias/Amalaya_3D_original.zip`.

## Blender y motores de juego
GLB es la ruta principal entregada y validada como archivo. El script `scripts/importar_blender.py` importa la geometría JSON en colecciones nuevas, sin eliminar objetos anteriores; está preparado pero no se ejecutó Blender en esta sesión. Abrirlo desde su carpeta original en el editor de texto de Blender y ejecutarlo. Después guardar un .blend. Las colecciones de propuesta y zonas quedan ocultas por defecto.

En Unreal, importar los GLB mediante el importador compatible de la instalación. Confirmar el tamaño con la barra de 100 m del mapa: Unreal trabaja habitualmente en centímetros, pero el archivo declara geometría en metros; no aplicar dos veces una conversión automática. La entrega no incluye un proyecto Unreal probado, navmesh ni colisiones de producción. El recorrido disponible ya funciona en el visor web.

## Método de los tutoriales y alternativa fotorealista
Se verificó la documentación primaria de Blosm. Su método usa datos OSM para calles y huellas, atributos disponibles para alturas y valores por defecto donde no hay datos. Importar no recupera automáticamente las fachadas reales. La base editable de esta entrega sigue ese enfoque, conservando la procedencia por objeto.

Tutorial de Nicko16 enlazado por la documentación oficial: https://www.youtube.com/watch?v=Thx08Q4etVc
Documentación: https://github.com/vvoovv/blosm/wiki/Documentation
Otro tutorial localizado: https://www.youtube.com/watch?v=y5fEy3nmBgo
No se revisaron íntegramente los videos; las indicaciones se contrastaron con documentación oficial.

La alternativa Cesium + Google utiliza mallas fotográficas transmitidas por internet. Google publica un mapa de cobertura: el relieve mundial no equivale a edificios 3D en todas las ciudades. No se confirmó de forma fiable la cobertura de superficies 3D para Plaza Hidalgo en esta sesión.
- Cobertura oficial: https://developers.google.com/maps/documentation/javascript/3d/coverage
- Uso de tiles: https://developers.google.com/maps/documentation/tile/3d-tiles
- Guía oficial Unreal: https://cesium.com/learn/unreal/unreal-photorealistic-3d-tiles/
- Políticas: https://developers.google.com/maps/documentation/tile/policies

El acceso de producción requiere cuenta/token o clave y, según la vía, facturación habilitada. No se creó una cuenta, no se contrató un servicio ni se extrajo una ciudad de Google para distribuirla offline. No hace falta esa cuenta para usar este paquete.

## Cambios recientes a contrastar en campo
El Imparcial reportó el inicio de demolición del antiguo edificio de la Procuraduría/Edificio Soto en Rosales y Álvaro Obregón el 28 de agosto de 2026. Esto se registra como evidencia temporal, no como levantamiento del estado final. No se eliminan otras geometrías por semejanza o proximidad. Revisar ese cruce antes de usar la escena para obras o circulación actual.
https://www.elimparcial.com/son/hermosillo/2026/08/28/demuelen-antiguo-edificio-de-la-procuraduria-en-hermosillo-para-mejorar-la-distribucion-vial/

## Datos necesarios para una réplica fiel
El siguiente responsable puede continuar sin rehacer el trabajo:
- Validar los límites exactos de A01 y cada Z con plano de predios o CAD georreferenciado. Confirmar la correspondencia de Z05, Z08, Z09 y Z10.
- Medir al menos tres referencias independientes distribuidas por el conjunto; ajustar y comprobar los residuos sobre puntos adicionales.
- Levantar alturas, cubiertas y fachadas con fotos propias/autorizadas, dimensiones o nube de puntos. Fotografías laterales por sí solas no producen un levantamiento métrico.
- Incorporar terreno medido o DEM con resolución adecuada si se quiere representar pendientes y Cerro de la Campana. Este paquete no contiene alturas de terreno.
- Documentar fecha por edificio, estado existente/propuesto/demolido y grado de confianza.
- Sustituir progresivamente las geometrías conservando los ID; actualizar las transformaciones en `registro_laminas.json`, nunca mover sin guardar el cambio.

## Reproducibilidad
Fuentes OSM originales en `fuentes/`, parámetros en `datos/`, geometrías trianguladas en `datos/escena.json` y scripts en `scripts/`.
Para regenerar los archivos principales: instalar `scripts/requirements.txt`, ejecutar `scripts/construir.py` y `scripts/exportar_cad.py`.
Para recompilar el HTML: instalar `three` y `esbuild` en la raíz del paquete y ejecutar `node scripts/compilar_visor.mjs`. No se necesitan esos paquetes para abrir el HTML ya generado.
No se requiere ni se recomienda subir estas hipótesis a OpenStreetMap.

## Atribución
Datos OSM: © OpenStreetMap contributors, ODbL. https://www.openstreetmap.org/copyright
Las láminas del usuario y la propuesta mantienen su procedencia separada; no se atribuyen a OSM. La fotografía base de la lámina territorial no se entrega como una ortofoto cartográfica autorizada independiente. El mapa reutilizable de esta entrega es el dibujado desde geometrías abiertas.
Three.js: licencia MIT incluida en `scripts/three_LICENSE.txt`.

## Ampliación de huellas y licencia
La base completa contiene 434 edificios: 24 huellas OSM y 410 detecciones de Microsoft Global ML Building Footprints. Se seleccionaron 448 detecciones dentro del ámbito y se excluyeron 38 por solape con OSM. Son detecciones sobre imágenes de fechas diversas; no certifican existencia actual ni perímetros medidos. Las alturas ausentes se representan con 6 m ilustrativos.
Fuente oficial: https://github.com/microsoft/GlobalMLBuildingFootprints (release 2026-08-13). La fuente y el recorte original se conservan en fuentes/. Licencia CDLA Permissive 2.0 incluida en fuentes/CDLA-Permissive-2.0.txt; conservarla al redistribuir estos datos.
Los 434 OBJ individuales están en modelos/edificios_individuales/. Base_urbana_OSM.glb conserva únicamente la base OSM; Base_urbana_completa.glb incorpora también las detecciones. Las ocho piezas originales con fachadas, azoteas e isométricos se conservan en referencias/Amalaya_3D_original.zip.
